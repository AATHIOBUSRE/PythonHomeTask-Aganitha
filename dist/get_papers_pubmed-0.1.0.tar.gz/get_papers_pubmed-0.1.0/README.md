# get-papers

Fetch PubMed research papers with at least one author from pharmaceutical or biotech companies.
